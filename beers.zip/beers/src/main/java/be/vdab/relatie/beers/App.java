package be.vdab.relatie.beers;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       
    }
}
