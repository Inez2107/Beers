package beers;

public enum BeerType {
	HOME,BEERS;
}
